from django.shortcuts import render,HttpResponse,reverse,redirect
import pandas as pd
from .models import Transaction,keywords,Employee
from django.http import HttpResponseRedirect
import csv
import io
from django.contrib import messages
import os
import math
from django.core.mail import send_mail
from django.http import JsonResponse
from django.views import View


# Create your views here.
'''
    context={
        "variable1":"Hi",
        "variable2":"Hello"
    }
   '''
 #return render(request,'index.html',context)
 # 
# def index(request):
#      return render(request,'index.html')
 



'''
def upload_file(request):
    
    if request.method == 'POST':
        excel_file = request.FILES['excel_file']
        if excel_file.name.endswith('.csv'):
            df = pd.read_excel(excel_file)
            for _, row in df.iterrows():
                # Access row data and save it to the database
               # YourModel.objects.create(column1=row['Column1'], column2=row['Column2'],...)
            # Redirect or render a success message
             return render(request, 'success.html')
        else:
            # Handle invalid file format error
            return render(request, 'error.html', {'error': 'Invalid file format. Only .csv files are supported.'})
   
    return render(request, 'success.html')
'''


# def upload_csv(request):
#      if request.method == 'POST':
#         csv_file = request.FILES.get('csv_file')
        
#         if csv_file is not None and csv_file.name.lower().endswith('.csv'):
        
#             # Process the CSV file and store data in the database
#           csv_file_text = io.TextIOWrapper(csv_file.file, encoding='iso-8859-1')
#           csv_data = csv.reader(csv_file_text)
#           next(csv_data)
#           for row in csv_data:
#             # Extract data from each row and create instances of YourModel
#             transaction = Transaction(transaction_ref=row[0],value_date=row[1],payer_name = row[2],payer_account = row[3]
#                                      ,payee_name = row[4] ,payee_account = row[5],amount = row[6])
           
#             transaction.save()
          
#           #return render(request, 'services.html', {'message': 'File uploaded successfully.'})
#           pass_count=60
#           fail_count=4
#           context={
                
#                 'var3':pass_count,
#                 'var4':fail_count
#             }

           
#             #messages.success(request, success_message)
#           return render(request, 'services.html',context)
        
#         else:
#            #  return render(request, 'services.html', {'message': 'Please upload a CSV file.'})
#             messages.success(request, 'Please Upload a CSV File') 
#             return render(request, 'services.html')

    
#      else:
#        messages.success(request, 'File could not be uploaded it doesnot satisy the given format')
#        return render(request, 'services.html')

import pandas as pd
import csv
import io
from django.shortcuts import render
from django.contrib import messages
from .models import Transaction
from datetime import datetime
import tempfile
import re
# /def index(request):
# //    return render(request, 'index.html')


def upload_csv(request):
     if request.method == 'POST':
        csv_file = request.FILES.get('csv_file')
        
        if csv_file is not None and csv_file.name.lower().endswith('.csv'):
           # messages.success('File uploaded successfully!')
            decoded_file = csv_file.read().decode('utf-8').splitlines()
            reader = csv.reader(decoded_file)
        

            
            temp_file = tempfile.TemporaryFile(mode='w+', encoding='utf-8')
            for chunk in csv_file.chunks():
             temp_file.write(chunk.decode('utf-8'))
             temp_file.seek(0)  # Reset the file pointer to the beginning of the file

# Read the CSV data from the temporary file
            record_count = 0
            csv_reader = csv.reader(temp_file)
            for row in csv_reader:
             record_count += 1

# Close and delete the temporary file
            temp_file.close()


            pass_count_val = 0  # Count of records validated as pass
            pass_count_screen = 0  # Count of records validated as fail
            next(reader)

            for index,record in enumerate(reader, start=1):

                # Perform validation on each row
                is_valid, errorfields=validate_row(record,record_count)
                if (is_valid==True):
                    # Extract data from each row and create instances of YourModel
                    pass_count_val+=1
                    

    # Perform case-insensitive keyword matching for Payee Name and Payer Name
                    payee_name = record[4].lower()
                    payer_name = record[2].lower()


                    matching_records1 = keywords.objects.filter(keyword=payee_name)
                    matching_records2 = keywords.objects.filter(keyword=payer_name)
    # Check if any matching records are found
                    if matching_records1.exists() and matching_records2.exists():
                              transaction = Transaction(
                              transaction_ref=record[0],
                              value_date=record[1],
                              payer_name=record[2],
                              payer_account=record[3],
                              payee_name=record[4],
                              payee_account=record[5],
                              amount=record[6],
                              status="Screen-Fail",
                              error_fields="Fraudulent Payee and Payer Name"
                            )
                             
                              transaction.save()

                    elif matching_records1.exists():
                              
                              transaction = Transaction(
                              transaction_ref=record[0],
                              value_date=record[1],
                              payer_name=record[2],
                              payer_account=record[3],
                              payee_name=record[4],
                              payee_account=record[5],
                              amount=record[6],
                              status="Screen-Fail",
                              error_fields="Fraudulent Payee name"
                            )
                           
                              
                              transaction.save()

                    elif matching_records2.exists():
                              
                             
                              transaction = Transaction(
                              transaction_ref=record[0],
                              value_date=record[1],
                              payer_name=record[2],
                              payer_account=record[3],
                              payee_name=record[4],
                              payee_account=record[5],
                              amount=record[6],
                              status="Screen-Fail",
                              error_fields="Fraudulent Payer Name"
                            )
                             
                             
                              transaction.save()

                          
                              
                    else:
                              transaction = Transaction(
                              transaction_ref=record[0],
                              value_date=record[1],
                              payer_name=record[2],
                              payer_account=record[3],
                              payee_name=record[4],
                              payee_account=record[5],
                              amount=record[6],
                              status="Screen-Pass",
                              error_fields=""
                              
                            )
                              pass_count_screen+=1
                              transaction.save()
                             

    # Save the updated status in the database
                         

                
                        
                else:
                    
                      transaction = Transaction(
                        transaction_ref=record[0],
                        value_date=record[1],
                        payer_name=record[2],
                        payer_account=record[3],
                        payee_name=record[4],
                        payee_account=record[5],
                        amount=record[6],
                        status="Validation Fail",
                        error_fields=errorfields

                    )
                      transaction.save()
                    
            
            #Screening of Transaction
            
 # Get the current timestamp in the format YYYYMMDDHHMMSS
            timestamp = datetime.now().strftime('%Y-%m-%d_%H.%M.%S')
        
        # Get the original filename
            original_filename = csv_file.name
        
        # Add the timestamp to the filename
        # For example, if the original filename is 'data.csv', the new filename will be 'data_20230910143012.csv'
            new_filename = f"{os.path.splitext(original_filename)[0]}_{timestamp}{os.path.splitext(original_filename)[1]}"
        

            with open(os.path.join('uploads', new_filename), 'wb+') as destination:
             for chunk in csv_file.chunks():
                destination.write(chunk)
                    


            context={
                
                'a':pass_count_val,
                'b':pass_count_screen
            }

 
            return render(request,'popup.html',context)
        
            
        
        
        else:
            messages.error(request, 'Please upload a CSV file.')
            return render(request, 'services.html')
     else:
        messages.error(request, 'No file selected!')
        return render(request, 'services.html')

def validate_row(record,record_count):
            flag=0
            error_fields=[]

            
           
            if(record[6].startswith('-')):
                 error_fields.append("Amount:Expected Positive")
                 flag=flag+1
            
            currency_field = record[6]
           # pattern = r'^\d{1,10}(\.\d{1,2})?$'
           # if re.match(pattern, currency_field):   
           #     flag1=flag
           ## else:
            #    flag=flag+1

            num_str = str(currency_field)

    # Split the number into the integer and decimal parts
            if '.' in num_str:
             integer_part, decimal_part = num_str.split('.')
            else:
             integer_part = num_str
             decimal_part = ""

    # Check if the integer and decimal parts have the desired lengths
             if len(integer_part) <= 10 and len(decimal_part) == 2:
              
              flag1=0
             else:
              error_fields.append("Amount:Max length value 10.2")
              flag=flag+1
            
            
            if(check_numbers_in_string(record[2])==True):
                 error_fields.append("Payer Name:Expected alphabets only")
                 flag=flag+1
            
            if((check_numbers_in_string(record[4])==True)):
                 error_fields.append("Payee Name:Expected alphabets only")
                 flag=flag+1
            
            if(check_alphabets_in_string(record[0])==True):
                 error_fields.append("Transaction Ref Id:Expected alphabets only")
                 flag=flag+1 
            
            if(check_alphabets_in_string(record[3])==True) :
                error_fields.append("Payer Account:Expected Numeric Value only")
                flag=flag+1

            
            if((check_alphabets_in_string(record[5])==True)):
                 error_fields.append("Payee Account:Expected Numeric Value only")
                 flag=flag+1

            if (check_alphabets_in_string(record[6])==True):
                error_fields.append("Amount:Expected Numeric Value Only")
                flag=flag+1


            #cleaned_date_string = ''.join(filter(str.isdigit, record[1]))
           # datetime.strptime( record[1],'%d-%m-%Y')
            #if record[1].strip():
            formatted_date = record[1].zfill(8)
            if formatted_date:  # Check if the date string is not empty
             if datetime.strptime( formatted_date, '%d%m%Y').date() != datetime.today().date():
               error_fields.append("Date:Expected Current Date")
               flag += 1
            
           # print(formatted_date)
            #exists = Transaction.objects.filter(transaction_ref=record[0]).exists()
            #if(exists==True):
            #   flag=flag+1

            number_string = str(record[0])
            length = len(number_string)

            if(length!=12) :
              error_fields.append("Transaction Ref Id:Expected field length 12")
              flag=flag+1
            
            if(len(str(record[3]))!=12):
                error_fields.append("Payer Account:Expected field length 12")
                flag=flag+1
            
            if(len(str(record[5]))!=12):
                error_fields.append("Payee Account:Expected field length 12")
                flag=flag+1

            if(len(str(record[2]))>35):
                error_fields.append("Payer Name:Expected field length 35")
                flag=flag+1
            
            if(len(str(record[4]))>35):
                error_fields.append("Payee Name:Expected field length 35")
                flag=flag+1

            #if(record_count!=7):
            #   error_fields.append("Expected No empty fields")
            #  flag=flag+1
               





            #if(len(record[3])!=12) :
            #   flag=flag+1
            
            #if(len(record[5])!=12) :
            #   flag=flag+1
            
           # if(len(record[1])!=8):
            #   flag=flag+1
            
            #if(len(record[2])>35 or len(record[4])>35):
             #   flag=flag+1
            #if(record_count!=7):
             #   flag=flag+1




            
            


            

          
            """
            if len(record) != 7:
              flag=flag+1
            

            if(len(record[3])!=12):
              flag=flag+1
            
            
            if(len(record[5])!=12):
              flag=flag+1

            for field in record:
             if len(field) > 35:
                flag=flag+1
                break


            

            

            

            # Validate the total number of records in the CSV file
            # Subtract 1 to exclude the header row
            '''''
            if (record_count-1) != 500:
               flag=flag+1
            
            
            # Validate the field length
            
            '''   
            # if record[6].isalnum() and not record[6].isalpha():
            #     flag=flag+1
          

          
            # currency_field = record[6]
            # pattern = r'^\d{1,10}(\.\d{1,2})?$'
            # if re.match(pattern, currency_field):   
            #     flag1=flag
            # else:
            #     flag=flag+1
            
             
           

            
           
            
        
            
           
           
            
            #Transaction ref id should be unique and not alpha numeric string
            # Desired date format: "date, month, year"
            desired_format = r'\d{2}- \d{2}- \d{4}'
            date_string = record[1]
            # Check if the date matches the desired format
            try:
                datetime.strptime(date_string, '%d-%m-%Y')
            except:
                flag=flag+1


            
            """
         
            if(flag>0):
               return False,','.join(error_fields)
               
            else:
               return True,""
def check_numbers_in_string(string):
    return any(char.isdigit() for char in string)

def check_alphabets_in_string(string):
    return any(char.isalpha() for char in string)

def service(request):
    return render(request, 'services.html')


from django.http import JsonResponse

def get_integer(request):
    integer_value = 42  # Replace with your own logic
    return JsonResponse({'integer': integer_value})

# def records_count(request):
#     pass_records_count = Transaction.objects.filter(status='Validation Pass').count()
#     context = {'pass_records_count': pass_records_count}
#     return render(request, 'popup.html', context)

def validation_fail(request):
    fail_records = Transaction.objects.filter(status="Validation Fail")
    context = {'fail_records': fail_records}
    return render(request, 'validation_fail.html', context)

def download_csv(request):
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="validation_fail_records.csv"'
    writer = csv.writer(response)
    writer.writerow(['Transaction ref', 'Value date', 'Payer name', 'Payer account', 'Payee name', 'Payee account', 'Amount', 'Error Fields'])

    filter_date_str = request.GET.get('filter_date')
    
    if filter_date_str:
        # If a filter date is provided, apply the filter
        fail_records = Transaction.objects.filter(status="Validation Fail", value_date=filter_date_str)
    else:
        # If no filter date is provided, get all records with status "Validation Fail"
        fail_records = Transaction.objects.filter(status="Validation Fail")

    for record in fail_records:
        writer.writerow([record.transaction_ref, record.value_date, record.payer_name, record.payer_account,
                         record.payee_name, record.payee_account, record.amount, record.error_fields])

    return response


def validation_pass(request):
    pass_records = Transaction.objects.filter(status="-Pass ")
    pass_records1 = Transaction.objects.filter(status="Screen-Fail")
    context = {'pass_records': pass_records,'pass_records1':pass_records1}
    return render(request, 'validation_pass.html', context)

def download_csv1(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="validation_pass_records.csv"'
    writer = csv.writer(response)
    writer.writerow(['Transaction ref', 'Value date', 'Payer name', 'Payer account', 'Payee name', 'Payee account', 'Amount'])
    
    filter_date_str = request.GET.get('filter_date')
    
    if filter_date_str:
        # If a filter date is provided, apply the filter
        pass_records = Transaction.objects.filter(status="Screen-Pass",value_date=filter_date_str)
        for record in pass_records:
          writer.writerow([record.transaction_ref, record.value_date, record.payer_name, record.payer_account,
                         record.payee_name, record.payee_account, record.amount])
      
        pass_records1 = Transaction.objects.filter(status="Screen-Fail",value_date=filter_date_str)
        for record in pass_records1:
          writer.writerow([record.transaction_ref, record.value_date, record.payer_name, record.payer_account,
                         record.payee_name, record.payee_account, record.amount])
    else:
        # If no filter date is provided, get all records with status "Validation Fail"
        pass_records = Transaction.objects.filter(status="Screen-Pass")
        for record in pass_records:
          writer.writerow([record.transaction_ref, record.value_date, record.payer_name, record.payer_account,
                         record.payee_name, record.payee_account, record.amount])
      
        pass_records1 = Transaction.objects.filter(status="Screen-Fail")
        for record in pass_records1:
          writer.writerow([record.transaction_ref, record.value_date, record.payer_name, record.payer_account,
                         record.payee_name, record.payee_account, record.amount])

   
    return response
    
    
    
    
    
    
   

    
    


def screen_pass(request):
    pass_records = Transaction.objects.filter(status="Screen-Pass")
    context = {'pass_records': pass_records}
    return render(request, 'screen_pass.html', context)

def download_csv2(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="screening_pass_records.csv"'
    writer = csv.writer(response)
    writer.writerow(['Transaction ref', 'Value date', 'Payer name', 'Payer account', 'Payee name', 'Payee account', 'Amount'])
    
    filter_date_str = request.GET.get('filter_date')
    
    if filter_date_str:
        # If a filter date is provided, apply the filter
        fail_records = Transaction.objects.filter(status="Screen-Pass", value_date=filter_date_str)
    else:
        # If no filter date is provided, get all records with status "Validation Fail"
        fail_records = Transaction.objects.filter(status="Screen-Pass")

    for record in fail_records:
        writer.writerow([record.transaction_ref, record.value_date, record.payer_name, record.payer_account,
                         record.payee_name, record.payee_account, record.amount, record.error_fields])

    return response

def screen_fail(request):
    fail_records = Transaction.objects.filter(status="Screen-Fail")
    context = {'fail_records': fail_records}
    return render(request, 'screen_fail.html', context)

def download_csv3(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="screening_fail_records.csv"'
    writer = csv.writer(response)
    writer.writerow(['Transaction ref', 'Value date', 'Payer name', 'Payer account', 'Payee name', 'Payee account', 'Amount','Error Fields'])
    
    filter_date_str = request.GET.get('filter_date')
    
    if filter_date_str:
        # If a filter date is provided, apply the filter
        fail_records = Transaction.objects.filter(status="Screen-Fail", value_date=filter_date_str)
    else:
        # If no filter date is provided, get all records with status "Validation Fail"
        fail_records = Transaction.objects.filter(status="Screen-Fail")

    for record in fail_records:
        writer.writerow([record.transaction_ref, record.value_date, record.payer_name, record.payer_account,
                         record.payee_name, record.payee_account, record.amount, record.error_fields])

    return response


def admin(request):
    # Redirect to the admin index page
    return redirect('admin:index')

def upload_keyword(request):
     pass_records = Employee.objects.filter()
   
     context = {'pass_records': pass_records}
     return render(request, 'keyword.html', context)

def download_csvv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="employee_reimbursement_records.csv"'
    writer = csv.writer(response)
    writer.writerow(['Employee ID', 'Employee Name', 'Department', 'Reimbursement Amount', 'Bill Image', 'OCR Generated Text', 'Status','Date'])
    
    filter_date_str = request.GET.get('filter_date')
    
    if filter_date_str:
        # If a filter date is provided, apply the filter
        records = Employee.objects.filter(Date=filter_date_str)
    else:
        # If no filter date is provided, get all records with status "Validation Fail"
        records = Employee.objects.filter()

    for record in records:
        writer.writerow([record.emp_id,record.name,record.department,record.reimbursement_amount,record.bill_image,record.ocr_generated_text,record.status,record.Date])

    return response



 

           
        
           
              
def keyword(request):
    return render(request,'keyword.html')


def contactUs(request):
    return render(request,'contactUs.html')



######################
import pytesseract
from PIL import Image

# def index(request):
#     if request.method == 'POST':
#         emp_id = request.POST['emp_id']
#         name = request.POST['name']
#         department = request.POST['department']
#         reimbursement_amount = request.POST['reimbursement_amount']
#         bill_image = request.FILES['bill_image']

#         # Save the data and image to the database
#         employee = Employee.objects.create(
#             emp_id=emp_id,
#             name=name,
#             department=department,
#             reimbursement_amount=reimbursement_amount,
#             bill_image=bill_image,
#         )

#         # Perform OCR and prediction
#         ocr_result, status = process_image_ocr(employee)
#         employee.ocr_generated_text = ocr_result
#         employee.status = status
#         employee.save()

#         context={
#              emp_id:employee.id
#         }
#         return render(request,'result.html',context)
#     else:
#         return render(request, 'index.html')

# def process_image_ocr(employee):
#     try:
#         # Save the uploaded image to a temporary location
#         with open('temp.jpg', 'wb') as f:
#             for chunk in employee.bill_image.chunks():
#                 f.write(chunk)

#         # Perform OCR using pytesseract
#         ocr_result = pytesseract.image_to_string('temp.jpg')

#         # Perform machine learning prediction (implement this separately)
#         status = perform_machine_learning_prediction(ocr_result)

#         return ocr_result, status
#     except Exception as e:
#         return f"Error occurred: {str(e)}", None

# def perform_machine_learning_prediction(ocr_text):
#     # Implement your machine learning model prediction here
#     # Use the preprocessed OCR text to get the status
#     # (e.g., 'Rembursement anamoly detected' or 'Rembursement sanctioned')
#     # You can use the previously trained and loaded machine learning model here.
#     pass

# # def capture_reimbursement(request):
# #     if request.method == 'POST':
# #         form = ReimbursementForm(request.POST, request.FILES)
        
# #             # Process the form data and captured image here
# #         emp_id = request.POST['emp_id']
# #         name = request.POST['name']
# #         department = request.POST['department']
# #         reimbursement_amount = request.POST['reimbursement_amount']
# #         bill_image = request.FILES['bill_image']
# #             # Perform further processing, e.g., saving the image, calculating reimbursement, etc.
# #             # You can use Django's FileField to save the image
# #             # Example: employee.bill_image = bill_image
# #             #         employee.save()
            
# #             # Return a response to indicate successful processing
# #         return HttpResponse("Reimbursement submitted successfully.")
  

# #     return render(request, 'your_template_name.html', {'form': form})
import pytesseract
from django.shortcuts import render, redirect
from .models import Employee
import datetime
import cv2
import numpy as np
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer


def index(request):
    if request.method == 'POST':
        emp_id = request.POST['emp_id']
        name = request.POST['name']
        department = request.POST['department']
        reimbursement_amount = request.POST['reimbursement_amount']
        captured_image_data = request.POST.get('captured_image_data')
        bill_image = request.FILES['bill_image']
        
        if captured_image_data:  # Check if captured image is not null
            bill_image = captured_image_data  # Use captured image if available
        
        current_date = datetime.date.today()


        try:
           formatted_date = current_date.strftime('%d%m%Y')
        except AttributeError:
           formatted_date = None

        # Save the data and image to the database
        print(formatted_date)
        employee = Employee.objects.create(
            emp_id=emp_id,
            name=name,
            department=department,
            reimbursement_amount=reimbursement_amount,
            bill_image=bill_image,
            Date=formatted_date,
        )

        # Perform OCR and prediction
        ocr_result, status = process_image_ocr(employee)
        employee.ocr_generated_text = ocr_result
        employee.status = status
        employee.save()
        context={
            status:status
        }
        return render(request,'popup2.html')
    else:
        return render(request, 'index.html')

def process_image_ocr(employee):
    try:
        
# Read the image
        
        
        # Save the uploaded image to a temporary location
        with open('temp.jpg', 'wb') as f:
            
            for chunk in employee.bill_image.chunks():
                f.write(chunk)
        img = cv2.imread('temp.jpg',0)
# Simple thresholding
        ret,thresh1 = cv2.threshold(img,210,255,cv2.THRESH_BINARY)
       
        blurred_image = cv2.GaussianBlur(img, (5, 5), 0)
        # gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Apply Gaussian blur to reduce noise and smooth the image
        # blurred_image = cv2.GaussianBlur(gray_image, (5, 5), 0)

    # Apply adaptive thresholding to create a binary image
        threshold_image = cv2.adaptiveThreshold(
        blurred_image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
        )
      
        # Perform OCR using pytesseract
        ocr_result = pytesseract.image_to_string(threshold_image)

        # Perform machine learning prediction (implement this separately)
        status = perform_machine_learning_prediction(ocr_result)

        return ocr_result, status
    except Exception as e:
        return f"Error occurred: {str(e)}", None



vectorizer = joblib.load('../vectorizer.joblib')
model = joblib.load('../train-model.joblib')

def perform_machine_learning_prediction(ocr_result):
    # Vectorize the OCR text using the loaded vectorizer
    vectorized_text = vectorizer.transform([ocr_result])

    # Perform prediction
    prediction = model.predict(vectorized_text)

    # Determine the status based on the prediction
    status = 'Fraudulent' if prediction[0] == 1 else 'Non-Fraudulent'

    # Save the OCR text and status in the database
    return status
