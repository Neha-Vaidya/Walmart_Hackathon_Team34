from django.db import models

# Create your models here.
class Transaction(models.Model):
    transaction_ref = models.CharField(("Transaction ref"), max_length=12, primary_key=True)
    value_date = models.CharField(("Value date"),max_length=8)
    payer_name = models.CharField(("Payer name"),max_length=35)
    payer_account = models.CharField(("Payer account"),max_length=12)
    payee_name = models.CharField(("Payee name"),max_length=35)
    payee_account = models.CharField(("Payee account"),max_length=12)
    amount = models.CharField(("Amount"),max_length=14)
    status=models.CharField(("Status"),max_length=35,default="null")
    error_fields=models.CharField(("Error Fields"),max_length=100,default="null")
    

class keywords(models.Model):
    keyword=models.CharField(("Fraud Keywords"),max_length=35,primary_key=True)


class Employee(models.Model):
    emp_id = models.CharField(("Employee Id"),max_length=20)
    name = models.CharField(("Employee Name"),max_length=100)
    department = models.CharField(("Department"),max_length=100)
    reimbursement_amount = models.DecimalField(("Reimbursement Amt"),max_digits=10, decimal_places=2)
    bill_image = models.ImageField(("Bill Image"),upload_to='bill_images/')
    ocr_generated_text = models.TextField(("OCR Generated Text"),null=True, blank=True)
    status = models.CharField(("Status"),max_length=100, null=True, blank=True)
    Date=models.DateTimeField(("Date"),auto_now=True)

    def _str_(self):
        return self.name