"""
URL configuration for Hello project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from Home import views


urlpatterns = [
   path("",views.index,name="Home"),
  #path("about",views.about,name="About"),
   path('services/',views.service,name='services'),
    path('upload_csv/', views.upload_csv, name='upload_csv'),
     path('get-integer/', views.get_integer, name='get_integer'),
     path('validation_fail/', views.validation_fail, name='validation_fail'),
     path('download_csv/', views.download_csv, name='download_csv'),
     path('validation_pass/', views.validation_pass, name='validation_pass'),
     path('download_csv1/', views.download_csv1, name='download_csv1'),
     path('screen_pass/', views.screen_pass, name='screen_pass'),
     path('download_csv2/', views.download_csv2, name='download_csv2'),
     path('screen_fail/', views.screen_fail, name='screen_fail'),
     path('download_csv3/', views.download_csv3, name='download_csv3'),
     path('admin/', views.admin, name='admin'),
     path('upload_keyword/', views.upload_keyword, name='upload_keyword'),
     path('keyword/', views.keyword, name='keyword'),
     path('contactUs/',views.contactUs,name="contactUs"),
     path('download_csvv/',views.download_csvv,name="download_csvv"),

     #path('index1/',views.index1,name="index1"),
    #path('success/', views.success_page, name='success_page'),
   #path("contact",views.contact,name="Contact"),
]
